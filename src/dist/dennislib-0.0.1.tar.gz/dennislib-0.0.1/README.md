# Homework_4

URL for GitHub repository: https://github.com/2545046941/Homework_4

# graghs_Dennis

This package implements Dijkstra's algorithm.

# Installation 

You can install the package using : 

pip install git+https://github.com/2545046941/Homework_4.git

# Run Dijkstra's algorithm

python test.py - path-to-graph-file 

Example: python test.py example1.txt 

